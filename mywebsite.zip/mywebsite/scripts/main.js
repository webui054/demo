/**
 * Created by Dmytro on 16.03.2015.
 */
var myApp = angular.module('MyWebSite', []);

myApp.controller('MainCtrl', ["$scope", "$http", "$filter", "$interval", function ($scope, $http, $filter, $interval) {
    $scope.tab = 1;

    $scope.selectTab = function(setTab){
        $scope.tab = setTab;
    };
    $scope.isSelected = function(checkTab){
        return $scope.tab === checkTab;
    };

    $scope.userName = "";
    $scope.userAge = "";
    $scope.nameFilterValue = "";

    $scope.brand = 'ЛНУ';
    $scope.claim = 'Заявка';
    $scope.listOfClaim='Список заявок';
    $scope.proposalsForMembership='Пропозиції на вступ';
    $scope.ExamInfo ='Екзаменаційні відомості';
    $scope.log='Журнал реєстрації';

    $scope.isLogin = false;
    $scope.message = 'Everyone come and see how good I look!';
    $scope.tempData = {};
    $scope.tempFilterData2='';
    $scope.tempFilterData = [{name: 'Ivano-Fankivsk'},{name: 'Lviv'},{name: 'Chernivtsi'},{name: 'Kyiv'}]

    $scope.tempDataArray = [];

    // UI

    $('#testModal').on('shown.bs.modal', function () {

    });

    $('#testModal').on('hidden.bs.modal', function () {

    });

    $scope.showModal = function(id) {
        if (id === null) {
            return;
        }
        setTimeout(function() {
            $(id).modal('show');
        }, 500);
    };
    var realPath = "";
    var tempPath = 'tempData/tempDataArray.json';
    var path = tempPath;
    (function(){
        $http.get(path)
            .success(function(data){
                console.log(data);
                //$scope.tempDataArray = angular.fromJson(data);
                $scope.tempDataArray = (data);
                $scope.tempData.name = 'Dima';
                $scope.tempData.age = 28;
                $scope.tempDataArray.push($scope.tempData)
            })
            .error(function(msg){
                console.log(msg);
            });
    }());

    $scope.AddNewUser = function(name,age){
        $("#addUserModal").modal("hide");
        var tempUser = {};
        if(name === null && age === null){
            tempUser.name = 'Default';
            tempUser.age = 0;
            $scope.tempDataArray.push(tempUser);
        }
        else{
            tempUser.name = name;
            tempUser.age = age;
            $scope.tempDataArray.push(tempUser);
            $scope.userName = "";
            $scope.userAge = "";

        }
    }
}]);

myApp.directive('loginContent', function() {
    return {
        templateUrl: 'login.html'
    };
});
myApp.directive('claimContent', function() {
    return {
        templateUrl: 'claimView.html'
    };
});
myApp.directive('listContent', function() {
    return {
        templateUrl: 'listView.html'
    };
});

